#define UTS_MACHINE		"x86_64"
#define LINUX_COMPILE_BY	"kernel"
#define LINUX_COMPILE_HOST	"kathleen"
#define LINUX_COMPILER		"x86_64-linux-gnu-gcc-12 (Ubuntu 12.3.0-1ubuntu1) 12.3.0, GNU ld (GNU Binutils for Ubuntu) 2.40"
