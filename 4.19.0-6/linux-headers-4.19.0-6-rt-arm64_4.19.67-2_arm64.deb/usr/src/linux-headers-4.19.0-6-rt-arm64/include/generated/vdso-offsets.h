#define vdso_offset_sigtramp	0x0698
